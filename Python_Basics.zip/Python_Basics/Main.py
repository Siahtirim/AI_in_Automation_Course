from cal_div import divider as div
from cal_div import mul as m

z = div(200, 20)
print(z)

y = m(110,20)
print(y)