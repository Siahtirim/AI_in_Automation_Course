def divider(a,b):
    return a/b

def mul(aa,bb):
    return aa*bb